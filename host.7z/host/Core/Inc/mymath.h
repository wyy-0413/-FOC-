#ifndef MYMATH_H
#define MYMATH_H



float invSqrt(float x) ;

#endif

