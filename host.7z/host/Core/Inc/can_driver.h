#ifndef CAN_DRIVER_H
#define CAN_DRIVER_H

#include "project.h"

extern uint8_t date_CAN1[4];


 

void CAN_Start(CAN_HandleTypeDef *hcan);
uint8_t CANx_SendExtData(CAN_HandleTypeDef* hcan,uint32_t ID,uint8_t *pData,uint16_t Len);
uint8_t CANx_SendStdData(CAN_HandleTypeDef* hcan,uint16_t ID,uint8_t *pData,uint8_t Len);
void CANFilterConfig_Scale32_IdMask(CAN_HandleTypeDef * hcan,uint32_t ID,uint32_t Mask,uint8_t ID_Type,uint8_t Filter_Nunber); 
void CANFilterConfig_Scale16_IdList(CAN_HandleTypeDef * hcan,uint32_t StdId1,uint32_t StdId2,uint32_t StdId3,uint32_t StdId4,uint8_t Filter_Nunber); 
void CANFilterConfig_Scale32_IdList(CAN_HandleTypeDef * hcan,uint32_t StdId0,uint32_t StdId1,uint8_t Filter_Nunber );  
void CAN1_Send_Test(void);

#endif
