#ifndef IMU_H
#define IMU_H



//��̬�����ĽǶ�
typedef struct
{
	float roll;
	float pitch;
	float yaw;
}FLOAT_ANGLE;

union FLOAT_INT{
    float f;
    uint8_t bytes[4];
};

#define G			9.80665f		      	// m/s^2	
#define RadtoDeg    57.324841f				//���ȵ��Ƕ� (���� * 180/3.1415)
#define DegtoRad    0.0174533f				//�Ƕȵ����� (�Ƕ� * 3.1415/180)

extern FLOAT_ANGLE mpu_angle;
extern union FLOAT_INT u_yaw;
extern union FLOAT_INT u_pitch;
extern union FLOAT_INT u_roll;
 
void IMUupdata(FLOAT_ANGLE *mpu_angle,MPU_DATA *mpu_data);
void Motor_Control(FLOAT_ANGLE *mpu_angle);






#endif
