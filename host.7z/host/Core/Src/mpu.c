#include "project.h"

KalmanFilter kalman_Ax, kalman_Ay, kalman_Az;
float Gx_LPF = 0, Gy_LPF = 0, Gz_LPF = 0;
	uint8_t offset[14];
	uint8_t raw[14];
MPU_OFFSET mpu_offset;
MPU_DATA mpu_data;


void Kalman_Init(KalmanFilter *kf, float Q, float R) {
    kf->x_hat = 0.0f;
    kf->P = 1.0f;
    kf->Q = Q;
    kf->R = R;
}

void MPU_Filter_Init(void) {
    Kalman_Init(&kalman_Ax, 0.01f, 1.0f);
    Kalman_Init(&kalman_Ay, 0.01f, 1.0f);
    Kalman_Init(&kalman_Az, 0.01f, 1.0f);
}

//�������˲�����
float Kalman_Update(KalmanFilter *kf, float measurement) {
    // Ԥ��Э����
    kf->P += kf->Q;
    // ���㿨��������
    kf->K = kf->P / (kf->P + kf->R);
    // ���¹���ֵ
    kf->x_hat += kf->K * (measurement - kf->x_hat);
    // ����Э����
    kf->P *= (1 - kf->K);
    return kf->x_hat;
}



//��ȡ��ֹ��ֵȥ��ƫ
void MPU_Offset(void)
{
		int32_t Ax_sum = 0, Ay_sum = 0, Az_sum = 0;
    int32_t Gx_sum = 0, Gy_sum = 0, Gz_sum = 0;
    uint8_t success_count = 0;
	
	  for (int i = 0; i < 10; i++) {
        if (NRF24L01_RxPacket(offset) == 0) {
            int16_t Ax = (int16_t)(offset[0] << 8 | offset[1]);
            int16_t Ay = (int16_t)(offset[2] << 8 | offset[3]);
            int16_t Az = (int16_t)(offset[4] << 8 | offset[5]);
            int16_t Gx = (int16_t)(offset[8] << 8 | offset[9]);
            int16_t Gy = (int16_t)(offset[10] << 8 | offset[11]);
            int16_t Gz = (int16_t)(offset[12] << 8 | offset[13]);

            Ax_sum += Ax;
            Ay_sum += Ay;
            Az_sum += Az;
            Gx_sum += Gx;
            Gy_sum += Gy;
            Gz_sum += Gz;
            success_count++;
        } else {
            printf("mpu_offset_read_fail #%d\r\n", i);
        }

        HAL_Delay(10); // �ȴ�10ms������̫���ȡ
    }

    if (success_count > 0) {
        mpu_offset.Ax_Raw = Ax_sum / success_count;
        mpu_offset.Ay_Raw = Ay_sum / success_count;
        mpu_offset.Az_Raw = Az_sum / success_count;
        mpu_offset.Gx_Raw = Gx_sum / success_count;
        mpu_offset.Gy_Raw = Gy_sum / success_count;
        mpu_offset.Gz_Raw = Gz_sum / success_count;

        printf("mpu_offset_ok\r\n");
    } else {
        printf("mpu_offset_all_fail\r\n");
    }
}


//����mpu����ֵ
void MPU_Update(void)
{
	
	int16_t Ax_raw,Ay_raw,Az_raw,Gx_raw,Gy_raw,Gz_raw;
	NRF24L01_RxPacket(raw);
	
	// ���ٶȼƣ������� uint8_t �ϳ�һ�� int16_t
	Ax_raw = (int16_t)(((uint16_t)raw[0] << 8) | raw[1]);
	Ay_raw = (int16_t)(((uint16_t)raw[2] << 8) | raw[3]);
	Az_raw = (int16_t)(((uint16_t)raw[4] << 8) | raw[5]);
	
	// ������
	Gx_raw = (int16_t)(((uint16_t)raw[8] << 8) | raw[9]);
	Gy_raw = (int16_t)(((uint16_t)raw[10] << 8) | raw[11]);
	Gz_raw = (int16_t)(((uint16_t)raw[12] << 8) | raw[13]);
	
  // У׼ת��Ϊ����ֵ
  float Ax = (Ax_raw - mpu_offset.Ax_Raw) * Acc_Gain;
  float Ay = (Ay_raw - mpu_offset.Ay_Raw) * Acc_Gain;
  float Az = (Az_raw - mpu_offset.Az_Raw) * Acc_Gain;

  float Gx = (Gx_raw - mpu_offset.Gx_Raw) * Gyro_Gr;
  float Gy = (Gy_raw - mpu_offset.Gy_Raw) * Gyro_Gr;
  float Gz = (Gz_raw - mpu_offset.Gz_Raw) * Gyro_Gr;
	
	// === �˲����� ===
  // ���ٶ� -> �������˲�
  mpu_data.Ax = Kalman_Update(&kalman_Ax, Ax);
  mpu_data.Ay = Kalman_Update(&kalman_Ay, Ay);
  mpu_data.Az = Kalman_Update(&kalman_Az, Az);

  // ������ -> һ�׵�ͨ�˲�
  Gx_LPF = Gx_LPF * (1.0f - GYRO_LPF_ALPHA) + Gx * GYRO_LPF_ALPHA;
  Gy_LPF = Gy_LPF * (1.0f - GYRO_LPF_ALPHA) + Gy * GYRO_LPF_ALPHA;
  Gz_LPF = Gz_LPF * (1.0f - GYRO_LPF_ALPHA) + Gz * GYRO_LPF_ALPHA;

  mpu_data.Gx = Gx_LPF;
  mpu_data.Gy = Gy_LPF;
  mpu_data.Gz = Gz_LPF;

}

